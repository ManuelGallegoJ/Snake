# Snake
Trabajo estructura de datos

## Integrantes

- Carlos David Arango.
- David Toro Arango.
- Manuel Alejandro Gallego Jiménez.
- Jerónimo Gómez Restrepo🤯🤯.

## NOTA

- ▲ : Es la cabeza de la serpiente
- 0 : Es el cuerpo de la serpiente
- @ : Es la manzana